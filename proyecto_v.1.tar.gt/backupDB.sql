mysqldump -R -u admin -h database-1.cs3pe9wko2np.us-east-2.rds.amazonaws.com -p proyecto2 > proyecto2.sql

mysql -u usuario -p proyecto2 < proyecto2.sql