<?php

?>

<!DOCTYPE html>
<html>
    <head>
        <title> INICIO </title>
        <style type="text/css">
            .links {
                bac
            }
        </style>
    </head>
    <body>
        <h1> Portal de Navegación </h1>
        <div class="links">
        <nav>
            <a href="loginA.php">Login ADMINISTRADOR</a>
            <br>
            <a href="loginC.php">Login USUARIO</a>
            <br>
            <a href="loginB.php">Login ATM</a>
        </nav>
        </div>
    </body>
</html>